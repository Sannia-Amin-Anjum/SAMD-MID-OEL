package com.example.samdoelmid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Garage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garage);

        Button btn1_signup=findViewById(R.id.btn_on);
        Button btn2_signup=findViewById(R.id.btn_off);

        btn1_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Garage Opened.",Toast.LENGTH_SHORT).show();

            }
        });
        btn2_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Garage Closed.",Toast.LENGTH_SHORT).show();

            }
        });

    }
}